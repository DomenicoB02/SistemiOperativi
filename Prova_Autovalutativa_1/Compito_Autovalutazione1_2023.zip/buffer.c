#include <unistd.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "buffer.h"


void send_values(char *char_1, char *char_2, int queue){
    
    Messaggio m;
    
    /* TODO: costruzione del messaggio da trasmettere */
    
    /* TODO: invio messaggio */
    
}

void leggi_buffer(buffer * b, int sem_id, char *char_1, char *char_2, int queue) {

    /* TODO: Inizio lettura */
    
    printf("[%d] Lettura buffer: char_1 = %c, char_2 = %c\n", getpid(), b->char_1, b->char_2);

    sleep(1);

    //LETTURA dei caratteri e conversione
    *char_1 = b->char_1 + 32;
    *char_2 = b->char_2 - 32;
    
    send_values(char_1, char_2, queue);

    /* TODO: Fine lettura */
}

void scrivi_buffer(buffer *b, int sem_id, char char_1, char char_2) {

    /* TODO: Inizio scrittura */
    
    printf("[%d] Scrittura buffer: char_1 = %c, char_2 = %c\n", getpid(), char_1, char_2);

    /* TODO: SCRITTURA dei caratteri sul buffer condiviso */
    b->char_1 = char_1;
    b->char_2 = char_2;

    /* TODO: Fine scrittura */
    
}
